## HOW TO INSTALL MODS

1. copy everything (3 items) within `BepInExPack` into the `Lethal Company` folder
2. made a folder in the (just pasted) `BepInEx` folder called `plugins`
3. paste all the other mod folders into this new folder

## RECOMMENDATIONS

-    rebind point to `F1`
-    rebind dance to `F2`
-    remove all the **More Emotes** keybinds

## KNOWN ISSUES

-    something prevents inviting or joining friends while the game is open - use the Steam client
-    attempting to invite friends from within the game opens a menu that you can't close
-    `SHIFT+TAB` for Steam stuff does not work
-    if you try to resize the console window the game will stop responding
-    if you close the console window the game will close (this is not an issue it's just how the game works)

## MOD LIST

1. **Boombox Controller v1.2.2** - play custom music from the boombox [link](https://thunderstore.io/c/lethal-company/p/KoderTeh/Boombox_Controller/versions/)
2. **HotbarPlus v1.5.7** - numeric hotkeys for a customizable number of inventory slots [link](https://thunderstore.io/c/lethal-company/p/FlipMods/HotbarPlus/versions/)
3. **LateCompany v1.0.11** - more lax clock-in rules [link](https://thunderstore.io/c/lethal-company/p/anormaltwig/LateCompany/versions/)
4. **MoreCompany v1.8.1** - sole proprietorship? more like limited liability corporation [link](https://thunderstore.io/c/lethal-company/p/notnotnotswipez/MoreCompany/versions/)
5. **More Emotes v1.3.3** - more emotes from a selection wheel [link](https://thunderstore.io/c/lethal-company/p/Sligili/More_Emotes/versions/)
6. **ShipLoot v1.0.0** - an accurate count of the loot on the ship [link](https://thunderstore.io/c/lethal-company/p/tinyhoot/ShipLoot/versions/)
7. **YippeeMod v1.2.4** - hoarding bugs say "yippee!" [link](https://thunderstore.io/c/lethal-company/p/sunnobunno/YippeeMod/versions/)

plus 1 dependency (**Runtime Netcode Patcher v0.2.5**) [link](https://thunderstore.io/c/lethal-company/p/Ozone/Runtime_Netcode_Patcher/versions/)
plus **BepInEx v5.4.2100**, of course [link](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/versions/)

---

last updated: 2024/03/28
