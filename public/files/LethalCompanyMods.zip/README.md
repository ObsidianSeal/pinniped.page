## HOW TO INSTALL MODS

1. copy everything (3 items) within `BepInExPack` into the `Lethal Company` folder
2. made a folder in the (just pasted) `BepInEx` folder called `plugins`
3. paste all the other mod folders into this new folder

## RECOMMENDATIONS

-    rebind point to `F1`
-    rebind dance to `F2`
-    remove all the **More Emotes** keybinds

## KNOWN ISSUES

-    something prevents inviting or joining friends while the game is open - use the Steam client
-    attempting to invite friends from within the game opens a menu that you can't close
-    `SHIFT+TAB` for Steam stuff does not work
-    if you try to resize the console window the game will stop responding

## MOD LIST

1. **ShipLoot** - an accurate count of the loot on the ship
2. **Boombox Controller** - play custom music from the boombox
3. **More Emotes** - more emotes from a selection wheel
4. **HotbarPlus** - numeric hotkeys for a customizable number of inventory slots
5. **YippeeMod** - hoarding bugs say "yippee!"

plus 1 dependency (**Runtime Netcode Patcher**)
plus BepInEx, of course

---

last updated: 2024/02/17
