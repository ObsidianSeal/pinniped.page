# v1.1

- Fixed items which cannot be turned in (like keys) counting towards the displayed total.
- Bodies do not count towards the displayed total.
- Added support for BMX's LobbyCompatibility if it is installed.
- Added config option for display duration.

# v1.0

- Initial release.